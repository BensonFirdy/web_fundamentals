function addLike() {
  itemCount.innerText++;
}

function addLike1() {
    itemCount1.innerText++;
  }
  
  function addLike2() {
    itemCount2.innerText++;
  }
  